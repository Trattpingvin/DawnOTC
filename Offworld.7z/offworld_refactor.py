import trueskill as ts
from collections import defaultdict

def get_data(name):
    with open(name) as f:
        lines = f.readlines()
        raw_matches = [l.lower() for l in lines]
    
    matches = []
    for i in range(0, len(raw_matches), 4): #gets 4 lines in a bunch
        a = lines[i].split()
        b = lines[i + 1].split()
        c = lines[i + 2].split()
        d = lines[i + 3].split()
        for j in range(0,8,2):
            players = [a[j], b[j], c[j], d[j]]
            wins = [1-int(a[j+1]), 1-int(b[j+1]), 1-int(c[j+1]), 1-int(d[j+1])] #0 is win, 1 is lose.
            matches.append([players, wins])
    return matches

def rating(matches):
    players = defaultdict(lambda: ts.Rating())

    for p, wins in matches:
        results = []

        participants = [(players[p[i]],) for i in range(4)]
        results = ts.rate(participants, ranks=wins)
        for i, r in enumerate(results):
            players[ p[i] ] = r[0] #rating is 1 length tuple
    return players

def weight_star_bracket(ratings):
    weighted = {}
    results = {}

    sigma_weight = 2 #Trueskill uses 3 by default; we use 2 here.

    #sorting data to divide brackets
    for k, v in ratings.items():
        weighted[k] = v.mu - sigma_weight * v.sigma
    sorted_ratings = sorted(weighted.items(), key=lambda kv: kv[1], reverse=True)
    
    #assign brackets, stars, and re-append trueskill rating.
    #also appended ratings so that it's easier to integrate with phil's ranks if needed.
    for i, p in enumerate(sorted_ratings):
        name = p[0]
        bracket = max(1, assigned_max_level - i // (len(sorted_ratings) // assigned_max_level))
        results[name] = [bracket, starting_stars, 0, ratings[name], weighted[name]]
    """
    #preview of data
    for k, v in results.items():
        print(v, k)
    """
    return results

def simulate_matches(matches, p):
    count = 0
    levelup = 0
    leveldown = 0
    locked = 0

    for match in matches:
        players, wins = match
        brackets = [ p[name][0] for name in players ]
        #p[name]: 0: bracket 1: star 2: medals 3: truskill rating 4: weighted rating

        for idx, name in enumerate(players):
            my_level = p[name][0]
            my_stars = p[name][1]
            my_stars_before = my_stars
            other_level = max(brackets[:idx] + brackets[idx+1:])
            winner_level = p[players[wins.index(0)]]
            awards = 0

            if wins[idx] == 0: #win
                #default bonus + bonus for defeating higher level player
                high_level_bonus = max(0, other_level - my_level)
                my_stars += win_bonus + high_level_bonus
                if high_level_bonus > 0:
                    awards += 1

            elif wins[idx] == 1: #lose
                #default malus
                my_stars += lose_malus #+ min(0, winner_level - my_level)

            if my_stars < 0:
                #only lose a level when lost at star 0.
                if my_stars_before == 0 and my_level > locked_level:
                        my_stars = default_lose_star
                        my_level = my_level - 1
                        leveldown += 1

                elif my_level == 1:
                    my_stars = my_stars_before #level 1 cannot lose stars.

                else:
                    my_stars = 0
                    locked += 1

            elif my_stars > max_star:
                #star_overflow = max_star - my_stars
                #if my_level == 1: print("level up!")
                if my_level == max_level:
                    awards += 1
                    my_stars = max_star
                else:
                    my_stars = default_win_star
                    my_level = my_level + 1
                    levelup += 1
                

            p[name][0] = my_level
            p[name][1] = my_stars
            p[name][2] += awards
        count += 1

    return p, [count, levelup, leveldown, locked]

def analyze_results(data):
    brackets = [0] * max_level
    awards = 0
    for _, v in data.items():
        brackets[v[0] - 1] += 1
        awards += v[2]
        
    print("Level status:", brackets, "from 1 to 5")
    print("Awards:", awards)

#control constants
max_level = 5 #number of brackets
assigned_max_level = 3
locked_level = 2 #cannot drop below this level

max_star = 3
starting_stars = 2 #default stars given at start
default_lose_star = 3
default_win_star = 1

win_bonus = 2
lose_malus = -1

if __name__ == "__main__":
    data1 = get_data("ABTdata1.txt")
    data2 = get_data("ABTdata.txt")
    data3 = rating(data1 + data2)
    seed = weight_star_bracket(data3)

    analyze_results(seed)
    simulation_results, c = simulate_matches(data1 + data2, seed)
    print()
    for k, v in simulation_results.items():
        #if v[0] > 0: print(v, k)
        pass

    analyze_results(simulation_results)
    print("Total matches:", c[0])
    print("Level Up-Down:", c[1], '/', c[2], '/ Freezed', c[3])